import React, { Component } from 'react';
import './App.css';
import Login from './Login/login.js';
import logo from './logo_gt.png';
import Dashboard from './Dashboard/dashboard.js';

class App extends Component {
	constructor(props) {
		super(props);
		this.state= {user:null,username: ''};
	}
	updateUser=(users)=>{
		let user=users;
		user={user:{code:users}}
		this.setState(user);
	}
	
	
	
  render() {
	  if(this.state.user === null){
    return (
      <div className="App">
        <header className="header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="title">Welcome</h1>
        </header>
        
          <Login setUser={this.updateUser} />
        
      </div>
    );
	 
	}
	else{
		return(
			<div>
			<Dashboard/>
			</div>
		);
	}
  }
}

export default App;
