import React, { Component } from 'react';
import ReactDOM from 'react-dom';

import './dashboard.css';
import Details from './details.js';

class Dashboard extends Component {
		
	
	
	
  render() {
    return (
		<div>
			<header className="headerD">
				<h1 className="titleD">User Dashboard</h1>
			</header>
			<div className="following">
				<h1>User Card</h1>
				<Details />
			</div>
		</div>
    );
  }
}

export default Dashboard;
