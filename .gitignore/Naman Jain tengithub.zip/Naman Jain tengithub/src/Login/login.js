import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import GitHubLogin from 'react-github-login';

import './login.css';

class Login extends Component {
	
	
	
	
	
	onSuccess = response => {this.props.setUser(response.code);console.log(response);}
    onFailure = response => console.error(response);
  render() {
    return (
		<div>
			<p className="clk">Click the button below to Sign-In</p>
			
		
        <GitHubLogin clientId="0262898a7dbc6deaaeca"
			redirectUri={""}
			onSuccess={this.onSuccess}
			onFailure={this.onFailure} 
			className="button" /> 
			</div>
    );
  }
}

export default Login;
